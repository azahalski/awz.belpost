<?php
namespace Awz\Belpost\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}