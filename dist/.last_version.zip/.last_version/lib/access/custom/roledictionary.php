<?php
namespace Awz\Belpost\Access\Custom;

use Awz\Belpost\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}