drop table if exists awz_belpost_role;
drop table if exists awz_belpost_role_relation;
drop table if exists awz_belpost_permission;