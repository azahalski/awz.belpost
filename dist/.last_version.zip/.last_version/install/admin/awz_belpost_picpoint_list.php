<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.belpost/admin/pickpoint_list.php");