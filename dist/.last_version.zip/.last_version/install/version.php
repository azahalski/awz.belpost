<?
$arModuleVersion = array(
    "VERSION" => "1.0.2",
    "VERSION_DATE" => "2026-02-21 23:40:00"
);