<?
$arModuleVersion = array(
    "VERSION" => "1.0.1",
    "VERSION_DATE" => "2026-02-20 12:29:00"
);