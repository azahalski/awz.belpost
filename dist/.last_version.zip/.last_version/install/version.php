<?
$arModuleVersion = array(
    "VERSION" => "1.0.4",
    "VERSION_DATE" => "2026-02-22 09:39:00"
);