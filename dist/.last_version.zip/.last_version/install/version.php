<?
$arModuleVersion = array(
    "VERSION" => "1.0.5",
    "VERSION_DATE" => "2026-02-26 23:31:00"
);